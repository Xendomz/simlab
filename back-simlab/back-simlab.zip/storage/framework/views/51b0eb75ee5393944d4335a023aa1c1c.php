<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Code\TUGAS AKHIR\simlab\back-simlab\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>