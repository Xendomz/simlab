<?php $__env->startComponent('mail::message'); ?>
# Yth. Pemilik e-mail : <?php echo e($booking->supervisor_name); ?>


Anda diminta untuk menjadi Dosen penanggung jawab dari : <br>

Nama Mahasiswa :  <?php echo e($booking->user->name ?? '-'); ?> <br>
NIM : <?php echo e($booking->user->identity_number ?? '-'); ?> <br>
Email Mahasiswa: <?php echo e($booking->user->email ?? '-'); ?> <br>
Program Studi: <?php echo e($booking->user->studyProgram->name ?? '-'); ?> <br>
Tujuan Penggunaan: <?php echo e($booking->purpose); ?>  <br>
Judul Proyek / Penelitian: <?php echo e($booking->activity_name); ?>  <br>

Email ini adalah hanya berupa notifikasi yang menyatakan bahwa ada mahasiswa yang sedang ingin meminjam ruangan di Laboratorium Terpadu ITK dan mahasiswa tersebut adalah salah satu anak didik dari Dosen Pembimbing / Penanggung Jawab Saudara. Apabila anda merasa tidak memiliki atau menaungi mahasiswa diatas silahkan lapor kepada Laboratorium Terpadu ITK melalui chat WhatsApp yang ada pada <a href="https://labterpadu.itk.ac.id/">https://labterpadu.itk.ac.id/</a> atau dapat menghubungi email lab terpadu di: labterpadu@itk.ac.id agar selanjutnya peminjaman ruangan dari mahasiswa tersebut akan kami tolak. <br> <br>

Terima Kasih,<br> <br><br> <br>
Laboratorium Terpadu <br>
Institut Teknologi Kalimantan.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Code\TUGAS AKHIR\simlab\back-simlab\resources\views/emails/booking_notification_supervisor.blade.php ENDPATH**/ ?>