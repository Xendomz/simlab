<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Code\TUGAS AKHIR\simlab\back-simlab\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>