<?php echo e($slot); ?>

<?php /**PATH D:\Code\TUGAS AKHIR\simlab\back-simlab\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>